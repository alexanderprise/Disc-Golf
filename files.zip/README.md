# Disc Golf Finder

A Progressive Web App (PWA) for exploring, tracking, and interacting with community-driven disc golf courses. This app helps users find nearby courses, keep score, report lost discs, and engage with other players through comments and the lost & found feature.

## Features

- **Course Directory:** Browse a list of disc golf courses, filter by holes or search by name.
- **Add Courses:** Contribute new course information to the directory.
- **Comments:** View and post comments for each course.
- **Scorecard:** Keep track of your round scores digitally.
- **My Scores:** View and manage your personal score history.
- **Lost & Found:** View lost discs reported by others or report your own lost disc.
- **PWA Support:** Installable and works offline with service worker.
- **Modern UI:** Built with Tailwind CSS and Inter font.

## Tech Stack

- **Frontend:** HTML5, Tailwind CSS, Vanilla JavaScript (ES Modules)
- **Backend:** [Firebase](https://firebase.google.com/) (Firestore for data, Auth for user management)
- **PWA:** Service worker and manifest included for offline capability

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (for local development, if you want to serve the app)
- Firebase account and project (for data storage and authentication)

### Local Setup

1. **Clone this repository:**

   ```bash
   git clone https://github.com/alexanderprise/Disc-Golf.git
   cd Disc-Golf
   ```

2. **Setup Firebase:**
   - Create a Firebase project at [firebase.google.com](https://firebase.google.com/).
   - Enable Firestore and Anonymous Authentication.
   - Get your Firebase config object from project settings.

3. **Configure the App:**
   - Inject your Firebase config as a global variable in your HTML (or using a build process).
   - Example (for development, place this _before_ the `<script type="module">` in your HTML):

     ```html
     <script>
       window.__firebase_config = JSON.stringify({
         apiKey: "...",
         authDomain: "...",
         projectId: "...",
         // ...other Firebase config properties
       });
       window.__app_id = "your-firebase-app-id";
     </script>
     ```

4. **Serve the App Locally:**

   - You can use any static server, e.g., with Python:

     ```bash
     python3 -m http.server 8080
     ```

   - Or use [live-server](https://www.npmjs.com/package/live-server):

     ```bash
     npx live-server .
     ```

5. **Access the App:**
   - Open [http://localhost:8080](http://localhost:8080) in your browser.

## Firebase Data Structure

- **Courses:** `/artifacts/{appId}/public/data/courses`
- **Comments:** `/artifacts/{appId}/public/data/comments`
- **Scorecards:** `/artifacts/{appId}/users/{userId}/scorecards`
- **Lost & Found:** `/artifacts/{appId}/public/data/lostandfound`

## Customization

- **Branding:** Update the header, theme colors in Tailwind, or add your own images.
- **Auth:** Anonymous authentication is used by default; you can extend to Google, email, etc.
- **Course Data:** Seed data is automatically added if the database is empty.

## PWA

- Includes a manifest and service worker for installability and offline use.
- Update `manifest.json` and `service-worker.js` to customize your PWA experience.

## Contributing

Pull requests are welcome! Please open an issue to discuss your ideas or report bugs.

## License

MIT

---

**Happy throwing!** 🥏